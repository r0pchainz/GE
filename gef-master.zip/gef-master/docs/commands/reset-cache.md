## Command reset-cache

This is an obsolete function to reset GEF internal memoize cache, which does not
need to be called from the command line anymore.

This command will disappear soon...
