## Command ropper

`ropper` is a gadget finding tool, easily installable via `pip`. It provides a
very convenient `--search` function to search gadgets from a regular
expression:

![ropper](https://pbs.twimg.com/media/Cm4f4i5VIAAP-E2.jpg:large)

`ropper` comes with a full set of options, all documented from the `--help` menu.
