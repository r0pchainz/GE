## Command help

Displays the help menu for the commands loaded.

![help](https://i.imgur.com/cvMoI3P.png)
