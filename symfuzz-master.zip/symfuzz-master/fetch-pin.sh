#!/bin/sh
wget 'http://software.intel.com/sites/landingpage/pintool/downloads/pin-2.14-67254-gcc.4.4.7-linux.tar.gz'
tar xfz pin-2.14-67254-gcc.4.4.7-linux.tar.gz
mv pin-2.14-67254-gcc.4.4.7-linux pin
rm pin-2.14-67254-gcc.4.4.7-linux.tar.gz
