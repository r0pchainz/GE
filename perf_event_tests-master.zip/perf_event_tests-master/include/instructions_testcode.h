int instructions_million(void);
int instructions_fldcw(void);
int instructions_rep(void);

