int branches_testcode(void);
int random_branches_testcode(int number, int quiet);

