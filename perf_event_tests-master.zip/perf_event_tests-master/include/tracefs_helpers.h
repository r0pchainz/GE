char *find_tracefs_location(char *buffer, int quiet);
