long long naive_matrix_multiply_estimated_flops(int quiet);
void naive_matrix_multiply(int quiet);


