int nops_testcode(void);
