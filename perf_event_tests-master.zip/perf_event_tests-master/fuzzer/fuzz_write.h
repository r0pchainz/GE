void write_random_event(void);
