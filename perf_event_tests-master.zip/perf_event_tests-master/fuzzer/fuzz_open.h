extern struct syscallentry syscall_perf_event_open;
void open_random_event(int mmap_enabled, int overflow_enabled);
