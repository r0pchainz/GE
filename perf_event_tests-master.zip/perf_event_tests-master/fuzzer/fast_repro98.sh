#!/bin/sh

while true; do ./perf_fuzzer -t OCIRMQWPFpAi -s 50000 ; done
