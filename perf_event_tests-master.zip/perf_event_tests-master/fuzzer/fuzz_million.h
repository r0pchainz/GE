void run_a_million_instructions(void);
