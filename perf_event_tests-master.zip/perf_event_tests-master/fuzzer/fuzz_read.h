void read_random_event(void);

