extern int already_forked;
extern pid_t forked_pid;

void fork_random_event(void);
