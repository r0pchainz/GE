void poll_random_event(void);

