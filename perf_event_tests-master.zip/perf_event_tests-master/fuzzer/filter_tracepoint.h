int make_tracepoint_filter(int which,
		char *filter, int size,
		int max_levels, int max_whitespace,
		int try_valid);
char *tracepoint_name(int which);
