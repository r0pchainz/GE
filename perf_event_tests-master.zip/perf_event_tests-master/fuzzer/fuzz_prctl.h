void prctl_random_event(void);

