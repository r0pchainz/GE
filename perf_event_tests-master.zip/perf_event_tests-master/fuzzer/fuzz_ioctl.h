extern int kprobe_id;

void ioctl_random_event(void);
