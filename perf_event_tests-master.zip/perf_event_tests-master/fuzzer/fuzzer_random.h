int rand_refresh(void);
int rand_period(void);
int rand_ioctl_arg(void);
uint64_t rand_open_flags(void);
