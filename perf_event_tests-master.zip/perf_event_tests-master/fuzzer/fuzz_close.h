void close_event(int i, int from_sigio);
void close_random_event(void);
