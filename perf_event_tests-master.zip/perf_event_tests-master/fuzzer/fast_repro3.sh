#!/bin/sh

while true; do ./perf_fuzzer -t OCMQ -s 20000 ; done
