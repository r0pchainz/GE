#!/bin/sh

while true; do ./perf_fuzzer -s 30000 ; done
