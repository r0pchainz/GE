#!/bin/sh

while true; do ./perf_fuzzer -t OC -s 20000 ; done
