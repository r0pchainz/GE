void access_random_file(void);
