int make_address_filter(
		int which,
		char *filter_out,
		int filter_size,
		int max_whitespace,
		int try_valid);
