void get_cpuinfo(char *cpuinfo);
