#!/bin/bash

sudo apt-get install kvm qemu-kvm

