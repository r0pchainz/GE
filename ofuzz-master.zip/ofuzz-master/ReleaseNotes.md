### New in 0.1.2 (Release 04/06/2015)
* Added a simple NCurses interface showing the current status

### New in 0.1.1 (Release 04/03/2015)
* Support GDB compiled with python3

### New in 0.1.0 (Release 03/30/2015)
* Initial release
