#ifndef UDIS86
#define UDIS86

extern "C" {
#include "types.h"
#include "input.h"
#include "itab.h"
#include "decode.h"
#include "extern.h"
};

#endif
