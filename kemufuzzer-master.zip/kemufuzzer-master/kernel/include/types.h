#ifndef TYPES_H
#define TYPES_H

#include <limits.h>

#define NULL ((void *)0)

#include <stdint.h>

#endif
