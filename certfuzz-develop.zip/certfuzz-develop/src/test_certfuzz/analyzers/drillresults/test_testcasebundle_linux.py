'''
Created on Jul 2, 2014

@organization: cert.org
'''
import unittest
from certfuzz.analyzers.drillresults import testcasebundle_linux


class Test(unittest.TestCase):

    def setUp(self):
        pass

    def tearDown(self):
        pass

    def testName(self):
        pass

if __name__ == "__main__":
    #import sys;sys.argv = ['', 'Test.testName']
    unittest.main()
