'''
Created on Jan 12, 2016

@author: adh
'''
from certfuzz.errors import CERTFuzzError


class ReporterError(CERTFuzzError):
    pass
