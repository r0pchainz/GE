'''
Created on Apr 12, 2013

@organization: cert.org
'''
from certfuzz.errors import CERTFuzzError


class TestCaseError(CERTFuzzError):
    pass
