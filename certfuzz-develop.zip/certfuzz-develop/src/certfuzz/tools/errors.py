'''
Created on Jul 1, 2014

@author: adh
'''
from certfuzz.errors import CERTFuzzError


class CERTFuzzToolError(CERTFuzzError):
    pass
