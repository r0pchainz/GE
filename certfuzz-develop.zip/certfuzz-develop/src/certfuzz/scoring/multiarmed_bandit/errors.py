'''
Created on Feb 22, 2013

@organization: cert.org
'''
from certfuzz.scoring.errors import ScoringError


class MultiArmedBanditError(ScoringError):
    pass
