'''
Created on Feb 22, 2013

@organization: cert.org
'''
from certfuzz.scoring.multiarmed_bandit.errors import MultiArmedBanditError


class BanditArmError(MultiArmedBanditError):
    pass
