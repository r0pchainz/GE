'''
Created on Oct 21, 2010

Provides the GDBfile class for analyzing gdb output.

@organization: cert.org
'''
from certfuzz.debuggers.output_parsers.debugger_file_base import DebuggerFile


class GDBfile(DebuggerFile):
    pass
