'''
Created on Jan 10, 2014

@author: adh
'''
from certfuzz.errors import CERTFuzzError


class ConfigError(CERTFuzzError):
    pass
