'''
Created on Feb 11, 2013

@organization: cert.org
'''


class CERTFuzzError(Exception):
    pass
