'''
Created on Jul 18, 2014

@author: adh
'''
from certfuzz.errors import CERTFuzzError


class TestCasePipelineError(CERTFuzzError):
    pass
