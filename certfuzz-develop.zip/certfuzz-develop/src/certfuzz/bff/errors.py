'''
Created on Apr 4, 2014

@author: adh
'''
from certfuzz.errors import CERTFuzzError


class BFFerror(CERTFuzzError):
    pass
