'''
Created on Jan 23, 2014

@author: adh
'''
from certfuzz.errors import CERTFuzzError


class IterationError(CERTFuzzError):
    pass
