'''
Created on Feb 8, 2012

@organization: cert.org
'''
from certfuzz.bff.windows import main

if __name__ == '__main__':
    main()
