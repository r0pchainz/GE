'''
Created on Oct 15, 2010

@organization: cert.org
'''
from certfuzz.bff.linux import main

if __name__ == '__main__':
    main()
