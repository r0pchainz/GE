"""Auto-generated file, do not edit by hand. 385 metadata"""
from ..phonemetadata import NumberFormat

PHONE_ALT_FORMAT_385 = [NumberFormat(pattern='(1)(\\d{3})(\\d{4})', format='\\1 \\2 \\3', leading_digits_pattern=['1']), NumberFormat(pattern='(1)(\\d{3})(\\d{2})(\\d{2})', format='\\1 \\2 \\3 \\4', leading_digits_pattern=['1']), NumberFormat(pattern='(6[09])(\\d{3})(\\d{4})', format='\\1 \\2 \\3', leading_digits_pattern=['6[09]']), NumberFormat(pattern='(\\d{2})(\\d{2})(\\d{4})', format='\\1 \\2 \\3', leading_digits_pattern=['[2-69]'])]
