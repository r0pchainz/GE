"""Auto-generated file, do not edit by hand. 372 metadata"""
from ..phonemetadata import NumberFormat

PHONE_ALT_FORMAT_372 = [NumberFormat(pattern='(\\d)(\\d{3})(\\d{3})', format='\\1 \\2 \\3', leading_digits_pattern=['6']), NumberFormat(pattern='(\\d{2})(\\d{2})(\\d{3})', format='\\1 \\2 \\3', leading_digits_pattern=['[69]|4[3-8]|5(?:[02]|1(?:[0-8]|95)|5[0-478]|6(?:4[0-4]|5[1-589]))|7[1-9]']), NumberFormat(pattern='(\\d{2})(\\d{3})(\\d{2})', format='\\1 \\2 \\3', leading_digits_pattern=['[69]|4[3-8]|5(?:[02]|1(?:[0-8]|95)|5[0-478]|6(?:4[0-4]|5[1-589]))|7[1-9]'])]
