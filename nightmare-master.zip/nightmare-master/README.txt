Nightmare
---------

Nightmare is a simple fuzzing suite that was created for an underground
conference (LaCon 2013). It was later on enhanced for the conference
SYSCAN 2014 (www.syscan.org), is actively mantained and was released for
T2 2014 conference.

Important notes
---------------

PLEASE DO READ ALL OF THE (SMALL) .TXT FILES IN THE "DOC/" DIRECTORY.
I'LL NOT ANSWER QUESTIONS ALREADY ANSWERED THERE (unless friend).

Install
-------

Please, refer to doc/install.txt for installation details.

Contact
-------

joxeankoret AT yahoo DOT es
