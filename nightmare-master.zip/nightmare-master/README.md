Nightmare
=========

A distributed fuzzing testing suite with web administration. It was released during the conference T2 (Finland) around October 23 (2014).

Please refer to README.txt for some more details and to all (small) .txt files in the "doc" directory.

