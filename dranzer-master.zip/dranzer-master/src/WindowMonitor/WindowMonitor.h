#ifndef __WindowMonitor_H
#define __WindowMonitor_H
#include <windows.h>
BOOL WindowMonitorStart(BOOL CloseWindows);
BOOL WindowMonitorStop(void);
#endif