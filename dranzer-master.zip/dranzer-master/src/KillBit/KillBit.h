#ifndef __KillBit_H
#define __KillBit_H
#include <wchar.h>
int GetKillBit(WCHAR *CLSID_Str_Wide);
#endif