# Global Variables
global host, port, minim, maxm, salt, plugin_use, pattern_flavour, timeout, show_pattern 