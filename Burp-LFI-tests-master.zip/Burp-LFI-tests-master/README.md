# Burp-LFI-tests
Fuzzing for LFI using Burpsuite
