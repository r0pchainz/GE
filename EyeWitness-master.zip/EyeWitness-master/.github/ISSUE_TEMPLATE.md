## OS Used - ALL Information (architecture, linux flavor, etc.)


## Pastebin link to error you are encountering


## Expected behavior (vs. what you encountered)


## Any additional information

