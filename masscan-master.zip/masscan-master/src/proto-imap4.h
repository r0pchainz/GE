#ifndef PROTO_IMAP4_H
#define PROTO_IMAP4_H
#include "proto-banner1.h"

extern const struct ProtocolParserStream banner_imap4;

#endif
