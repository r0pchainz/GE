#ifndef PROTO_POP3_H
#define PROTO_POP3_H
#include "proto-banner1.h"

extern const struct ProtocolParserStream banner_pop3;

#endif
