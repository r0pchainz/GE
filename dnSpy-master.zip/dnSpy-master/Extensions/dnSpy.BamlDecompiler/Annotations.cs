﻿namespace dnSpy.BamlDecompiler {
	internal class BamlConnectionId {
		public uint Id { get; }

		public BamlConnectionId(uint id) {
			Id = id;
		}
	}
}