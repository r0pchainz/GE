#!/bin/bash
sudo ifconfig en0 alias 10.0.0.1/24
