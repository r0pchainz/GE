# Moved to another github so that this git wasn't huge

Here:

https://github.com/nyxgeek/nyxgeek-slides/blob/master/TheWeakestLync.pdf
