#!/bin/bash
cd /vagrant
./panda_install.bash
