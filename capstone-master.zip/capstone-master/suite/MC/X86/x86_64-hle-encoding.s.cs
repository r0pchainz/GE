# CS_ARCH_X86, CS_MODE_64, None
0xf2 = repne 
0xf3 = rep 
