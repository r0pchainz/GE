from . import SimIRStmt

class SimIRStmt_AbiHint(SimIRStmt):
    def _execute(self):
        pass
