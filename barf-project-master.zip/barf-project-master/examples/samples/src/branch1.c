#include <stdio.h>

int main() {
    int cookie;

    if (cookie == 0x41424344) {
        printf("you win!\n");
    }
}
