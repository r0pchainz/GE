#include <stdio.h>

int main() {
    int rv = 1;
    int value;
    int amount;

    rv = value >> amount;

    return rv;
}