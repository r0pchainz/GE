#include <stdio.h>

int main() {
    int a;
    int b;
    int c;

    c = a * b + 5;

    return c;
}
