Introducción
============

*BARF* es un *framework* de análisis de binario. Está pensado para ser
multiplataforma y facilmente extensible.

La idea es permitir *cargar* cualquier binario, *traducirlo* a un lenguage
intermedio y *aplicar* algoritmos de análisis sobre este último.

*BARF* trabaja sobre un lenguaje intermedio llamado **REIL**.
