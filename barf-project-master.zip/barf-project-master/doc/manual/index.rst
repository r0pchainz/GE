.. BARF documentation master file, created by
   sphinx-quickstart on Fri May  9 17:00:40 2014.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Welcome to BARF's documentation!
===============================

Contents:

.. toctree::
   :maxdepth: 2

   source/introduction/index
   source/installation/index
   source/tutorial/index
   source/overview/index

Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
